UPDATE `sakila`.`menu` SET `className`='user' WHERE `id`='3';

UPDATE `sakila`.`menu` SET `className`='actorsgrid' WHERE `id`='5';
UPDATE `sakila`.`menu` SET `className`='categoriesgrid' WHERE `id`='6';
UPDATE `sakila`.`menu` SET `className`='languagesgrid' WHERE `id`='7';
UPDATE `sakila`.`menu` SET `className`='citiesgrid' WHERE `id`='8';
UPDATE `sakila`.`menu` SET `className`='countriesgrid' WHERE `id`='9';

UPDATE `sakila`.`menu` SET `className`='films' WHERE `id`='11';

UPDATE `sakila`.`menu` SET `className`='salesfilmcategory' WHERE `id`='13';
