Ext.define('Packt.model.security.Base', {
    extend: 'Packt.model.Base',

    idProperty: 'id',

    fields: [
        { name: 'id', type: 'int' }
    ]
});