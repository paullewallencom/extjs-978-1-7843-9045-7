Ext.define('Packt.model.film.SearchActor', {
    extend: 'Packt.model.staticData.Actor',

    //entityName: 'SearchActor',

    fields: [
        { name: 'film_info' }
    ]
});