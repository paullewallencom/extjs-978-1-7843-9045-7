Ext.define('Packt.store.staticData.Actors', {
    extend: 'Packt.store.staticData.Base',

    alias: 'store.actors',

    model: 'Packt.model.staticData.Actor'
});