Ext.define('Packt.store.staticData.Languages', {
    extend: 'Packt.store.staticData.Base',

    model: 'Packt.model.staticData.Language'
});