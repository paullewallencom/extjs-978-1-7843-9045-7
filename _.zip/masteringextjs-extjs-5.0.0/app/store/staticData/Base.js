Ext.define('Packt.store.staticData.Base', {
    extend: 'Ext.data.Store',

    storeId: 'staticDataAbstract',

    autoLoad: true
});