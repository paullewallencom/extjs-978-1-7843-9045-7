Ext.define('Packt.store.staticData.Countries', {
    extend: 'Packt.store.staticData.Base',

    model: 'Packt.model.staticData.Country'
});