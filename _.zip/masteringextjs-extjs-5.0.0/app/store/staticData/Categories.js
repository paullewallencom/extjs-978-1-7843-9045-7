Ext.define('Packt.store.staticData.Categories', {
    extend: 'Packt.store.staticData.Base',

    alias: 'store.categories',

    model: 'Packt.model.staticData.Category'
});