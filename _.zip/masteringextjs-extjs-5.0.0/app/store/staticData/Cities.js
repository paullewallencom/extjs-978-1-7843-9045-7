Ext.define('Packt.store.staticData.Cities', {
    extend: 'Packt.store.staticData.Base',

    model: 'Packt.model.staticData.City'
});