Ext.define('Packt.controller.Main', {
    extend: 'Ext.app.Controller'//,

//    init: function(application) {
//        this.control({
//            "app-main": {
//                afterrender: this.initiateControllers
//            }
//        });
//    },
//
//    initiateControllers: function(view, eOpts){
//
//        var me = this,
//            app = me.application;
//
//        app.createController('Menu');
//    }
});
