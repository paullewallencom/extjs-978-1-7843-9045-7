# ext-theme-aria/sass

This folder contains SASS files of various kinds, organized in sub-folders:

    ext-theme-aria/sass/etc
    ext-theme-aria/sass/src
    ext-theme-aria/sass/var
